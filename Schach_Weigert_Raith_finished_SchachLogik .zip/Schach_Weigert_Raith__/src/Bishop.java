import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Bishop extends Piece {
    static int[] CANDIDATE_MOVE_COORDINATES = {-9, -7, 7, 9};
    int candidateDestinationCoordinate;

    Bishop(int piecePosition, Alliance pieceAlliance) {
        super(PieceType.BISHOP, pieceAlliance,piecePosition);
    }

    @Override
    public Collection<Move> calculateLegalMoves(Board board) {

        List<Move> legalMoves = new ArrayList<>();

        for (int currentCandidateOffset : CANDIDATE_MOVE_COORDINATES) {
            int candidateCoordinateOffset = this.piecePosition;
            while (BoardUtils.isValidCoordinate(candidateDestinationCoordinate)) {
                if (isFirstColumnExcludet(candidateDestinationCoordinate, candidateCoordinateOffset)||isEightColumnExcludet(candidateDestinationCoordinate, candidateCoordinateOffset)){
                    break;

                }

                candidateDestinationCoordinate += candidateCoordinateOffset;
                if (BoardUtils.isValidCoordinate(candidateDestinationCoordinate)) {
                    final Tile candidateDestinationTile = board.getTile(candidateDestinationCoordinate);

                    if (!candidateDestinationTile.isTileOccupdied()) {
                        legalMoves.add(new Move.MajorMove(board, this, candidateDestinationCoordinate));
                    } else {
                        final Piece pieceAtDestination = candidateDestinationTile.getPiece();
                        final Alliance pieceAllience = pieceAtDestination.getPieceAlliance();

                        if (this.pieceAlliance != pieceAllience) {
                            legalMoves.add(new Move.AttackMove(board, this, candidateDestinationCoordinate, pieceAtDestination));
                        }
                    }
                    break;
                }
            }

        }
        return legalMoves;
    }

    @Override
    public Piece movePiece(Move move) {
        return new Bishop(move.getDestinationCoordinate(), move.getMovedPiece().getPieceAlliance());
    }

    @Override
    public String toString() {
        return PieceType.BISHOP.toString();
    }

    boolean isFirstColumnExcludet(int currentPosition, int candidateOffset){
        return BoardUtils.FIRST_COLUMN[currentPosition]&&(candidateOffset == -9 || candidateOffset == 7);
    }
    boolean isEightColumnExcludet(int currentPosition, int candidateOffset){
        return BoardUtils.FIRST_COLUMN[currentPosition]&&(candidateOffset == -7 || candidateOffset == 9);
    }
}