import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Stream;

public abstract class Player {
    protected Board board;
    protected King playerKing;
    Collection<Move> legalMoves;
    private final boolean isIncheck;

    public Player(Board board, Collection<Move> legalMoves, Collection<Move> opponentMoves)
    {
        List<Move> bothLegalAndCastleMoves = new ArrayList<>();
        bothLegalAndCastleMoves.addAll(legalMoves);
        bothLegalAndCastleMoves.addAll(calculateKingCastles(legalMoves, opponentMoves));

        this.board = board;
        this.playerKing = establishKing();
        this.legalMoves = bothLegalAndCastleMoves;
        this.isIncheck = !Player.calculateAttacksOnTile(this.playerKing.getPiecePosition(), opponentMoves).isEmpty();

    }

    public King getPlayerKing()
    {
        return this.playerKing;
    }

    public Collection<Move> getLegalMoves()
    {
        return this.legalMoves;
    }

    public static Collection<Move> calculateAttacksOnTile(int piecePosition, Collection<Move> moves) {
        final List<Move> attackMoves = new ArrayList<>();
        for (Move move : moves) {
            if(piecePosition == move.getDestinationCoordinate())
            {
                attackMoves.add(move);
            }
            
        }
        return attackMoves;
    }

    private King establishKing() {
        for(Piece piece : getActivePieces())
        {
            if(piece.getPieceType().isKing())
            {
                return (King) piece;
            }
        }
        throw new RuntimeException("Invalid Board init - relating king");
    }

    public boolean isMoveLegal(Move move)
    {
        return this.legalMoves.contains(move);
    }


    //noch implementieren!
    public boolean isInCheck()
    {
        return this.isIncheck;
    }

    public boolean isInCheckMate()
    {
        return this.isIncheck && !hasEscapeMoves();
    }

    public boolean hasEscapeMoves() {
        for(Move move : this.legalMoves)
        {
            MoveTransition transition = makeMove(move);
            if(transition.getMoveStatus().isDone())
            {
                return true;
            }
        }
        return false;
    }

    public boolean inInStaleMate()
    {
        return !this.isIncheck && !hasEscapeMoves();
    }

    public boolean isCastled()
    {
        return false;
    }

    public MoveTransition makeMove(final Move move)
    {
        if(!isMoveLegal(move))
        {
            return new MoveTransition(this.board, move, MoveStatus.ILLEGAL_MOVE);
        }

        final Board transitionBoard = move.execute();

        //kontrollieren ob wir uns selbst ins schach begeben wollen um das zu verhindern
        final Collection<Move> kingAttacks = Player.calculateAttacksOnTile(transitionBoard.currentPlayer().getOpponent().getPlayerKing().getPiecePosition(),
                transitionBoard.currentPlayer().getLegalMoves());

        if(!kingAttacks.isEmpty())
        {
            return new MoveTransition(this.board, move, MoveStatus.LEAVES_PLAYER_IN_CHECK);
        }

        return new MoveTransition(transitionBoard, move, MoveStatus.DONE);


    }

    public abstract Collection<Piece> getActivePieces();

    public abstract Alliance getAlliance();

    public abstract Player getOpponent();

    protected  abstract Collection<Move> calculateKingCastles(Collection<Move> playerLegals, Collection<Move> opponentsLegals);
}
