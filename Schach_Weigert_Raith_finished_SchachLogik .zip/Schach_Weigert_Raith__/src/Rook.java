import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Rook extends Piece{
    Rook(int piecePosition, Alliance pieceAlliance) {
        super(PieceType.ROOK, pieceAlliance,piecePosition);
    }
    private final static int[] CANDIDATE_MOVE_COORDINATES = {-8,-1,1,8};
    int candidateDestinationCoordinate;

    @Override
    public Collection<Move> calculateLegalMoves(Board board) {

        List<Move> legalMoves = new ArrayList<>();

        for (int currentCandidateOffset : CANDIDATE_MOVE_COORDINATES) {
            int candidateCoordinateOffset = this.piecePosition;
            while (BoardUtils.isValidCoordinate(candidateDestinationCoordinate)) {
                if (isFirstColumnExcludet(candidateDestinationCoordinate, candidateCoordinateOffset)||isEightColumnExcludet(candidateDestinationCoordinate, candidateCoordinateOffset)){
                    break;

                }

                candidateDestinationCoordinate += candidateCoordinateOffset;
                if (BoardUtils.isValidCoordinate(candidateDestinationCoordinate)) {
                    final Tile candidateDestinationTile = board.getTile(candidateDestinationCoordinate);

                    if (!candidateDestinationTile.isTileOccupdied()) {
                        legalMoves.add(new Move.MajorMove(board, this, candidateDestinationCoordinate));
                    } else {
                        final Piece pieceAtDestination = candidateDestinationTile.getPiece();
                        final Alliance pieceAllience = pieceAtDestination.getPieceAlliance();

                        if (this.pieceAlliance != pieceAllience) {
                            legalMoves.add(new Move.AttackMove(board, this, candidateDestinationCoordinate, pieceAtDestination));
                        }
                    }
                    break;
                }
            }

        }
        return legalMoves;

    }
    @Override
    public String toString() {
        return PieceType.ROOK.toString();
    }
    boolean isFirstColumnExcludet(int currentPosition, int candidateOffset){
        return BoardUtils.FIRST_COLUMN[currentPosition]&&(candidateOffset == -1);
    }
    boolean isEightColumnExcludet(int currentPosition, int candidateOffset){
        return BoardUtils.FIRST_COLUMN[currentPosition]&&(candidateOffset == 1);
    }

    @Override
    public Piece movePiece(Move move) {
        return new Rook(move.getDestinationCoordinate(), move.getMovedPiece().getPieceAlliance());
    }
}
