public enum Alliance {
    WHITE,BLACK
}
