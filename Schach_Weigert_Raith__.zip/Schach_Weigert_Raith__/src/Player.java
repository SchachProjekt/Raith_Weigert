import java.util.Collection;

public abstract class Player {
    protected Board board;
    protected King playerKing;
    Collection<Move> legalMoves;

    public Player(Board board, Collection<Move> legalMoves, Collection<Move> opponentMoves)
    {
        this.board = board;
        this.playerKing = establishKing();

    }

    private King establishKing() {
        for(Piece piece : getActivePieces())
        {
            if(piece.getPieceType().isKing())
            {
                return (King) piece;
            }
        }
        throw new RuntimeException("Invalid Board init - relating king");
    }

    public boolean isMoveLegal(Move move)
    {
        return this.legalMoves.contains(move);
    }

    public abstract Collection<Piece> getActivePieces();
    public abstract Alliance getAlliance();
    public abstract Player getOpponent();
}
