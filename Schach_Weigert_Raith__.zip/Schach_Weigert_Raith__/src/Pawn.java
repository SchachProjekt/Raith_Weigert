import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Pawn extends Piece{

    private static int[] CANDIDATE_MOVE_COORDINATES = {8, 16, 7, 9};

    Pawn(int piecePosition, Alliance pieceAlliance) {
        super(PieceType.PAWN, pieceAlliance,piecePosition);
    }

    @Override
    public Collection<Move> calculateLegalMoves(Board board) {

        final List<Move> legalMoves = new ArrayList<>();

        for (int currentCandidateOffset : CANDIDATE_MOVE_COORDINATES) {

            int candidateDestinastionCoordinate = this.piecePosition + (this.getPieceAlliance().getDirection() * currentCandidateOffset);

            if(!BoardUtils.isValidCoordinate(candidateDestinastionCoordinate))
            {
                continue;
            }

            if(currentCandidateOffset == 8 && !board.getTile(candidateDestinastionCoordinate).isTileOccupdied())
            {
                legalMoves.add(new Move.MajorMove(board, this, candidateDestinastionCoordinate));
            }
            else if(currentCandidateOffset == 16 &&  this.isFirstMove() &&
                    (BoardUtils.SECOND_ROW[this.piecePosition] && this.getPieceAlliance().isBlack()) ||
                    (BoardUtils.SEVENTH_ROW[this.piecePosition] && this.getPieceAlliance().isWhite())) {
                final int behindCandidateDestinationCoordinate = this.piecePosition + (this.pieceAlliance.getDirection() * 8);
                if(!board.getTile(behindCandidateDestinationCoordinate).isTileOccupdied() && !board.getTile(candidateDestinastionCoordinate).isTileOccupdied())
                {
                    legalMoves.add(new Move.MajorMove(board, this, candidateDestinastionCoordinate));
                } else if(currentCandidateOffset == 7 &&
                !(BoardUtils.EIGHTH_COLUMN[this.piecePosition] && this.pieceAlliance.isWhite() ||
                        (BoardUtils.FIRST_COLUMN[this.piecePosition]&& this.pieceAlliance.isBlack())))
                    if(board.getTile(candidateDestinastionCoordinate).isTileOccupdied())
                    {
                        final Piece pieceOnCandidate = board.getTile(candidateDestinastionCoordinate).getPiece();
                        if(this.pieceAlliance != pieceOnCandidate.getPieceAlliance())
                        {
                            legalMoves.add(new Move.MajorMove(board, this, candidateDestinastionCoordinate));
                        }
                    }

                else if(currentCandidateOffset == 9 &&
                            !(BoardUtils.FIRST_COLUMN[this.piecePosition] && this.pieceAlliance.isWhite() ||
                            (BoardUtils.EIGHTH_COLUMN[this.piecePosition]&& this.pieceAlliance.isBlack())))
                {
                    if(board.getTile(candidateDestinastionCoordinate).isTileOccupdied())
                    {
                        final Piece pieceOnCandidate = board.getTile(candidateDestinastionCoordinate).getPiece();
                        if(this.pieceAlliance != pieceOnCandidate.getPieceAlliance())
                        {
                            legalMoves.add(new Move.MajorMove(board, this, candidateDestinastionCoordinate));
                        }
                    }

                }


            }

        }

        return legalMoves;
    }
    @Override
    public String toString() {
        return PieceType.PAWN.toString();
    }
}
