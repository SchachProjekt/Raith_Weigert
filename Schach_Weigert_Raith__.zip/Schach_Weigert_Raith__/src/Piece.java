import java.util.Collection;

public abstract class Piece {

    PieceType pieceType;
    protected final int piecePosition;
    protected final Alliance pieceAlliance;
    protected final boolean isFirstMove;

    Piece(PieceType pieceType, final Alliance pieceAlliance,final int piecePosition)
    {
        this.pieceType = pieceType;
        this.pieceAlliance = pieceAlliance;
        this.piecePosition = piecePosition;
        this.isFirstMove = false;
    }

    public int getPiecePosition()
    {
        return this.piecePosition;
    }

    public Alliance getPieceAlliance()
    {
        return this.pieceAlliance;
    }

    public boolean isFirstMove()
    {
        return this.isFirstMove;
    }

    public PieceType getPieceType()
    {
        return this.pieceType;
    }

    public abstract Collection<Move> calculateLegalMoves(final Board board);

    enum PieceType{

        PAWN("P")
                {
                    @Override
                    public boolean isKing()
                    {
                        return false;
                    }
                },
        KNIGHT("K")
                {
                    @Override
                    public boolean isKing()
                    {
                        return false;
                    }
                },
        BISHOP("B"){
            @Override
            public boolean isKing()
            {
                return false;
            }
        },
        ROOK("R"){
            @Override
            public boolean isKing()
            {
                return false;
            }
        },
        QUEEN("Q"){
            @Override
            public boolean isKing()
            {
                return false;
            }
        },
        KING("K")
                {
                    @Override
                    public boolean isKing()
                    {
                        return true;
                    }
                };

        String pieceName;

        PieceType(String pieceName){
            this.pieceName = pieceName;
        }

        @Override
        public String toString() {
        return this.pieceName;
        }

        public abstract boolean isKing();
    }
}
