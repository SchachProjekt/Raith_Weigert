public class StartGame {
    public static void main(String[] args){
        Board board = Board.createstandardBoard();
        System.out.println(board);
    }
}
