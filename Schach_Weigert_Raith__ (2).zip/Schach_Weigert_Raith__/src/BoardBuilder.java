import java.util.HashMap;
import java.util.Map;

class BoardBuilder
{
    Map<Integer, Piece> boardConfig;
    Alliance nextMovemaker;

    public BoardBuilder()
    {
    this.boardConfig = new HashMap<>();
    }

    BoardBuilder setPiece(final Piece piece)
    {
        this.boardConfig.put(piece.getPiecePosition(), piece);
        return this;
    }

    public BoardBuilder setMoveMaker(final Alliance nextMovemaker)
    {
        this.nextMovemaker = nextMovemaker;
        return this;
    }

    public Board build()
    {
        return new Board(this);
    }
}