import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public abstract class Tile {

    protected final int tileCoordinate;

    private static final Map<Integer, EmtyTile> Emty_Tiles = createAllPossibleEmtyTiles();

    private static Map<Integer, EmtyTile> createAllPossibleEmtyTiles()
    {
        final Map<Integer, EmtyTile> emtyTileMap = new HashMap<>();

        for (int i = 0; i < 64; i++) {
            emtyTileMap.put(i, new EmtyTile(i));
        }

        return emtyTileMap;
    }

    public static Tile createTile(final int tileCoordinate, final Piece piece)
    {
        return piece != null ? new OccupiedTile(tileCoordinate, piece) : Emty_Tiles.get(tileCoordinate);
    }

    Tile(int tileCoordinate)
    {
        this.tileCoordinate = tileCoordinate;
    }

    public abstract boolean isTileOccupdied();

    public abstract Piece getPiece();

    public static final class EmtyTile extends Tile
    {
        EmtyTile(final int coordinate)
        {
            super(coordinate);
        }

        @Override
        public boolean isTileOccupdied()
        {
            return false;
        }

        @Override
        public Piece getPiece()
        {
            return null;
        }

        @Override
        public String toString() {
            return "-";
        }
    }


    public static final class OccupiedTile extends Tile
    {
        private final Piece pieceOnTile;

        OccupiedTile(int tileCoordinate, Piece pieceOnTile)
        {
            super(tileCoordinate);
            this.pieceOnTile = pieceOnTile;
        }


        @Override
        public String toString() {
            return getPiece().getPieceAlliance().isBlack()?getPiece().toString().toLowerCase(Locale.ROOT): getPiece().toString();
        }

        @Override
        public boolean isTileOccupdied()
        {
            return true;
        }

        @Override
        public Piece getPiece()
        {
            return this.pieceOnTile;
        }

    }
}
