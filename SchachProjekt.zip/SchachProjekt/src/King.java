public class King extends Figure{
    @Override
    public void canMove() {
        super.canMove();
    }
}
