public class Knight extends Figure{
    @Override
    public void canMove() {
        super.canMove();
    }
}