public class Bishop extends Figure{
    @Override
    public void canMove() {
        super.canMove();
    }
}
