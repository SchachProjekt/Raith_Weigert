public class Queen extends Figure{
    @Override
    public void canMove() {
        super.canMove();
    }
}
