public class Pawn extends Figure{
    @Override
    public void canMove() {
        super.canMove();
    }
}
