public class Figure {
    private String position[][];
    private char type;

    public void canMove()
    {

    }
}
